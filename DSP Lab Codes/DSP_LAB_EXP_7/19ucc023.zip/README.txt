Roll No. = 19ucc023
Name = Mohit Akhouri

In this experiment , i have used the given audio input file 'input.wav' in observation 1 for testing purposes.

For the rest of the observation , i have downloaded a new "3 second" audio file "input1.wav" to verify my codes. The reason for the same was that the provided "input.wav" was taking too much time to run on my computer for Observation 2 to 5.