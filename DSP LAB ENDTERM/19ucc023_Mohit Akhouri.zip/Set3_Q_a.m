% 19ucc023
% Mohit Akhouri
% This code will find the linear convolution of two sets of sequences
% Set 3 = Q (a)

% First set of sequence x[n] and h[n]
x1 = [1 2 3 4 5 6 7 8];
h1 = [1 0.5 0.75];

% Second set of sequence x[n] and h[n]
x2 = [1 2 3 4 5 6 7 8];
h2 = [0 0 0 1 0.5 0.25];

% calculating length of sequences
length_x1 = length(x1);
length_h1 = length(h1);
length_x2 = length(x2);
length_h2 = length(h2);

M1 = Set3_myLinConvMat(h1,length_x1); % Convolution matrix for first set
linconv_1_userdefined = Set3_myConv(x1,M1); % Linear convolution using user-defined function
linconv_1_inbuilt = conv(x1,h1); % Linear convolution using inbuilt function

M2 = Set3_myLinConvMat(h2,length_x2); % Convolution matrix for second set
linconv_2_userdefined = Set3_myConv(x2,M2); % Linear convolution using user-defined function
linconv_2_inbuilt = conv(x2,h2); % Linear convolution using inbuilt function

% Displaying the convolution matrices and linear convolution results
disp('Convolution matrix for part a(i) is :');
disp(M1);
disp('Linear Convolution result for part a(i) is as follows :');
disp(linconv_1_userdefined);

% Displaying the convolution matrices and linear convolution results
disp('Convolution matrix for part a(ii) is :');
disp(M2);
disp('Linear Convolution result for part a(ii) is as follows :');
disp(linconv_2_userdefined);

% Plotting x[n],h[n],conv_userdefined and conv_inbuilt for first set of
% sequences
figure;
subplot(2,2,1);
stem(x1,'Linewidth',1.);
xlabel('samples(n) ->');
ylabel('x_{1}[n] ->');
title('Plot of x_{1}[n] sequence');
grid on;
subplot(2,2,2);
stem(h1,'Linewidth',1.);
xlabel('samples(n) ->');
ylabel('h_{1}[n] ->');
title('Plot of impulse response h_{1}[n]');
grid on;
subplot(2,2,3);
stem(linconv_1_userdefined,'Linewidth',1.);
xlabel('samples(n) ->');
ylabel('x_{1}[n]*h_{1}[n] ->');
title('Plot of Linear Convolution obtained via USER-DEFINED function');
grid on;
subplot(2,2,4);
stem(linconv_1_inbuilt,'Linewidth',1.);
xlabel('samples(n) ->');
ylabel('x_{1}[n]*h_{1}[n] ->');
title('Plot of Linear Convolution obtained via INBUILT function conv');
grid on;
sgtitle('19ucc023 - Mohit Akhouri');

% Plotting x[n],h[n],conv_userdefined and conv_inbuilt for second set of
% sequences
figure;
subplot(2,2,1);
stem(x2,'Linewidth',1.);
xlabel('samples(n) ->');
ylabel('x_{2}[n] ->');
title('Plot of x_{2}[n] sequence');
grid on;
subplot(2,2,2);
stem(h2,'Linewidth',1.);
xlabel('samples(n) ->');
ylabel('h_{2}[n] ->');
title('Plot of impulse response h_{2}[n]');
grid on;
subplot(2,2,3);
stem(linconv_2_userdefined,'Linewidth',1.);
xlabel('samples(n) ->');
ylabel('x_{2}[n]*h_{2}[n] ->');
title('Plot of Linear Convolution obtained via USER-DEFINED function');
grid on;
subplot(2,2,4);
stem(linconv_2_inbuilt,'Linewidth',1.5);
xlabel('samples(n) ->');
ylabel('x_{2}[n]*h_{2}[n] ->');
title('Plot of Linear Convolution obtained via INBUILT function conv');
grid on;
sgtitle('19ucc023 - Mohit Akhouri');