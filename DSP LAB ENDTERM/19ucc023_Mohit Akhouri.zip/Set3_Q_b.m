% 19ucc023
% Mohit Akhouri
% This code will find the linear convolution for any length sequences
% In short , this code is a generalised code for linear convolution
% Set 3 = Q (b)

length_x = input('enter length of x[n] sequence : '); % input length of x[n]
length_h = input('enter length of h[n] sequence : '); % input length of h[n]

% Initializing x[n] and h[n] using zeros function
x = zeros(1,length_x);
h = zeros(1,length_h);

% entry of x[n] sequence
disp('entry of elements of x[n]');
for i=1:length_x
    x(i) = input('enter element of x[n]: ');
end

% entry of h[n] sequence
disp('entry of elements of h[n]');
for i=1:length_h
    h(i) = input('enter element of h[n]: ');
end

M = Set3_myLinConvMat(h,length_x); % Convolution matrix for use in linear convolution
y_userdefined = Set3_myConv(x,M); % User-defined linear convolution
y_inbuilt = conv(x,h); % inbuilt linear convolution

disp('Convolution matrix is as follows :');
disp(M);

% Plotting x[n],h[n],y_userdefined and y_inbuilt for first set of
% sequences
figure;
subplot(2,2,1);
stem(x,'Linewidth',1.);
xlabel('samples(n) ->');
ylabel('x[n] ->');
title('Plot of x[n] sequence');
grid on;
subplot(2,2,2);
stem(h,'Linewidth',1.);
xlabel('samples(n) ->');
ylabel('h[n] ->');
title('Plot of impulse response h[n]');
grid on;
subplot(2,2,3);
stem(y_userdefined,'Linewidth',1.);
xlabel('samples(n) ->');
ylabel('x[n]*h[n] ->');
title('Plot of Linear Convolution obtained via USER-DEFINED function');
grid on;
subplot(2,2,4);
stem(y_inbuilt,'Linewidth',1.);
xlabel('samples(n) ->');
ylabel('x[n]*h[n] ->');
title('Plot of Linear Convolution obtained via INBUILT function conv');
grid on;
sgtitle('19ucc023 - Mohit Akhouri');