function [y] = Set3_myConv(x,M)
% 19ucc023
% Mohit Akhouri
% Set 3 = Linear Convolution

% This code will calculate the Linear Convolution with the help of
% convolution matrix and input sequence x[n]

rows = size(M,1); % rows of convolution matrix M
columns = size(M,2); % columns of convolution matrix M

y = zeros(1,columns); % Initializing variable to store the convolved output
sum = 0; % temporary variable to store sum of linear convolution

% Algorithm for calculation of linear convolution is as follows
for i=1:columns
    sum = 0;
    for j=1:rows
       sum = sum + (M(j,i)*x(j));
    end
    y(i) = sum;
end     
end

