function [M] = myLinConvMat(h,n)
% 19ucc023
% Mohit Akhouri
% Set 3 = Linear Convolution

% This code will calculate the linear convolution matrix used in the
% computation of convolution.

% Here h is the impulse response, n is the length of the input sequence
% x[n]

rows = n; % initializing the number of rows of Convolution matrix M
length_h = length(h); % declaring the length of 'h'
columns = length(h) + n - 1; % declaring the number of columns of matrix M
M = zeros(rows,columns); % initializing the convolution matrix with zeros

% ALGORITHM for generation of convolution matrix is as follows

for i=1:rows
    offset = i; % offset value from where the 'h' values will be stored
    for j=1:length_h
        M(i,offset) = h(j); % storage of values in convolution matrix
        offset = offset + 1; % offset is incremented each time
    end
end
end

